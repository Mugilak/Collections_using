package stack;

import java.util.Stack;
import java.util.Vector;

public class stackDemonstration {
	public void entry() {
		Stack<Double> s = new Stack<>();             // if i use vector to instantiate Stack, it is not possible to use stack's 5 functions... 
		
		Vector<Integer> vector = new Stack<Integer>();
//		vector.push()
		((Stack<Integer>) vector).push(8);
		System.out.println("\n"+vector+"\n\n");
		
		System.out.println(s.isEmpty());
		s.add(9.9);
		s.push((double) 8);
		s.add(7.7);
		s.push(6.6);
		s.push(5.5);
		System.out.println(s.peek());
		System.out.println(s.empty());
		System.out.println(s.pop());
		System.out.println(s.peek());
		System.out.println(s.search(7.7));
		System.out.println(s.search(8));
//		System.out.println(s.isFull());                        // no such method
		
		System.out.println(s);
	}
}
