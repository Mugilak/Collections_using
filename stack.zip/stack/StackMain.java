package stack;

public class StackMain {

	public static void main(String[] args) {
		new stackDemonstration().entry();
	}

}
