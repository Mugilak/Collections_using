package Queue;

import java.util.LinkedList;
import java.util.Queue;

public class queueDemostration {
	public void entry() {
		Queue<String> q = new LinkedList<>();
		System.out.println(q.isEmpty());
		q.add("hi");
		q.offer("mugi");
		q.offer("k");
		q.add("12");

		System.out.println(q);

		System.out.println(q.poll());
		System.out.println(q);
		System.out.println(q.peek());
		System.out.println(q.remove());
		System.out.println(q);
		System.out.println(q.element());
		
		q.offer("Welcome");
		System.out.println(q);
//		System.out.println(q.isFull());                 // no such method
		
		q.clear();
		System.out.println(q);
	}
}
