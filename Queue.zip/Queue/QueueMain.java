package Queue;

public class QueueMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new queueDemostration().entry();
	}

}
