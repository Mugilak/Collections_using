package mapPrograms;

import java.util.*;

public class Hashmap {
	public void entry() {
		Map<Integer, Integer> map = new HashMap<>();
		map.put(1, 11);
		System.out.println(map);
		map.clear();
		System.out.println(map);
		map.put(2, null);
		System.out.println(map);
		for (int i = 1; i <= 10; i++) {
			map.putIfAbsent(i, i * 11);
		}
		System.out.println(map);
		map.remove(4, 44);
		map.remove(5, 44); // not removed because given in not pointing 44
		Iterator<Map.Entry<Integer, Integer>> iterate = map.entrySet().iterator();
		while (iterate.hasNext()) {
			Map.Entry<Integer, Integer> entry = iterate.next();
			System.out.println(entry.getKey() + " -> " + entry.getValue());
		}
		System.out.println(map.size());
		System.out.println(map.containsKey(5));
	}

}
