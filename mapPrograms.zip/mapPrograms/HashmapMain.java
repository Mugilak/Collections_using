package mapPrograms;

public class HashmapMain {

	public static void main(String[] args) {
		new Hashmap().entry();
	}

}
